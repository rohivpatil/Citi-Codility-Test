function emojify(a, b) {
    var is_obj = typeof a;
    if (is_obj == 'string') {
        console.log("string");
        var is_there = a.includes(" ");
        if (is_there) {
            console.log("space is there");
            var arr = a.split(" ");
            console.log(arr);
            var str = arr.join(":joy:");
            console.log(str);
        }
        else {
            console.log("No space is there");
            console.log("invalid string");
        }
    }
    else {
        console.log('[object object]');
    }
}
emojify({ rohini: 'patil' }, 'abc');

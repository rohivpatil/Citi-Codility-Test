import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  constructor() { }

  ngOnInit(): void {
  }
  term:any;
  items: any = [{ name: "Vanvatu" },
    { name: "Italy" },
    { name: "Spain" },
    { name: "Portugal" },
    { name: "Macedonia" },
    { name: "Mali" },
    { name: "Benin" },
    { name: "Norway" }
  ];
}



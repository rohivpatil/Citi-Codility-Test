function emojify(a:any, b:any){

    
    let is_obj=typeof a;
    if(is_obj=='string'){
      console.log("string");
      let is_there=a.includes(" ");

      if(is_there){
        console.log("space is there")
      let arr=a.split(" ");
      console.log(arr);
        let str=arr.join("@");  
        console.log(str);
    }else{
        console.log("No space is there")
        console.log("invalid string");
        
    }
    }else{
        console.log('[object@object]');
    }

    

}

emojify({rohini: 'patil'},'abc');